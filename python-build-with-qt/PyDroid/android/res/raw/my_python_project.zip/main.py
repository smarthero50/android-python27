import sys
import traceback

def main():
    from PyQt4 import QtCore
    from PyQt4 import QtGui
    from PyQt4 import QtDeclarative
    import sqlite3 as lite
    from list_view import ListView

    app = QtGui.QApplication(sys.argv)
    con = lite.connect('mydb.db')
    
    canvas = QtDeclarative.QDeclarativeView()
    rc = canvas.rootContext()

    todo = ListView(rc, con)
    
    rc.setContextObject(todo)
    canvas.setSource(QtCore.QUrl.fromLocalFile('todo.qml'))
    canvas.setGeometry(QtCore.QRect(100, 100, 350, 350))
    canvas.setResizeMode(QtDeclarative.QDeclarativeView.SizeRootObjectToView)

    
    canvas.show()
    app.exec_()
    
if __name__=="__main__":
    try:
        import android
        droid = android.Android()
        droid.aHelloFonction("====== hello from sl4a logcat log")
        droid.makeToast("Hello from Python 2.7 for Android... toast 1")
        droid.makeToast("Hello from Python 2.7 for Android... toast 2")
    except:
        fp = open('/sdcard/pyqt-error.txt', 'a')
        traceback.print_exc(file=fp)
        fp.flush()
        fp.close()
		
    try:
        main()	
    except:
        fp = open('/sdcard/pyqt-error2.txt', 'a')
        traceback.print_exc(file=fp)
        fp.flush()
        fp.close()
        sys.exit(1)
